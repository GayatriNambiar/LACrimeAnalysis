--//Number of BATTERY - SIMPLE ASSAULT from 2010-2017

declare @i int
set @i=2010
while(@i<=2017)
begin
select count(*) from Clean_CrimeDataset 
where [Crime Code Description] like '%BATTERY - SIMPLE ASSAULT%'
and year(convert(date,[Date Occurred])) = @i;
set @i=@i+1
end