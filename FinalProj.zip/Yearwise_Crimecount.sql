
declare @i int
set @i=2010
while(@i<=2017)
begin
select count(Clean_CrimeDataset.[Crime Code]) as total from Clean_CrimeDataset
where year(convert(date,[Date Occurred])) = @i
set @i=@i+1
end

