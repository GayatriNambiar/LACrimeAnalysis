import pandas as pd


df = \
    pd.read_csv('Crime_Data_from_2010_to_Present_Original.csv')

print("Crime reports in the City of Los Angeles from 2010 - present ")
print("Total number of crime incidents: " + str(len(df)))
print("Number of columns: " + str(len(df.columns)))
print(df.shape)
print('\n')

print("Total unique areas")
print(df['Area Name'].nunique())

print('\n')


print("Number of crimes by areas")
print(df.groupby('Area Name').size().sort_values(ascending=False))


print('\n')

print("Most Common crimes")
print(df.groupby('Crime Code Description').size().sort_values(ascending=False).head(10))


print('\n')


print("Date on which most number of crimes occurred")
print(df[].groupby('Date Occurred').size().sort_values(ascending=False).head(10))
#

# print('\n')

print("Date on which least number of crimes occurred")
print(df.groupby('Date Occurred').size().sort_values(ascending=True).head(10))

for x in range(2010, 2018):
    a = str(x)
    print("Most common crime on 01/01/" + a)
    print(df._where(df['Date Occurred'] == '01/01/' + a).groupby('Crime Code Description').size().sort_values(ascending=False).head(2))

print('\n')

